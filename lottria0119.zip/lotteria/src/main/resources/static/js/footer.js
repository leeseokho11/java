/**
 *  푸터 
 */



$(function() {
	$(".rollist").jCarouselLite({
		 	auto    : 5000
			, speed   : 1000
			, visible : 1  // 1개씩 보임
			, scroll  : 1  // 1개씩 스크롤
			, btnPrev : '.roll_control .btn_prev'
			, btnNext : '.roll_control .btn_next'
});
	$(".btn_stop_f").click(function() {
		jCarouselLite_running = true;
		$(this).hide();
		$(".btn_start_f").show();
	});
		$(".btn_start_f").click(function() {
	jCarouselLite_running = false;
		$(this).hide();
		$(".btn_stop_f").show();
	});
});
