/**
 * 이석호
 */

//자동롤링기능추가///
var rollingNum = 0;
var rollingInterval;
$(document).ready(function(){
	$('.rollingUl li').eq(rollingNum).show();
		rollingInterval = setInterval('autoRolling()',5000);
	$('.rollingCtrBtn').bind('click',function(){
		if($(this).hasClass('pauseType')){
		var rollingCtrBtnSrc = $('.rollingCtrBtn img').attr('src');
	$('.rollingCtrBtn img').attr({
									'src':rollingCtrBtnSrc.replace('pause.png','play.png'),
									'alt':'이벤트 자동재생 시작'
								});
								clearInterval(rollingInterval);
								$(this).removeClass('pauseType');
							}else{
								var rollingCtrBtnSrc = $('.rollingCtrBtn img').attr('src');
								$('.rollingCtrBtn img').attr({
									'src':rollingCtrBtnSrc.replace('play.png','pause.png'),
									'alt':'이벤트 자동재생 멈춤'
								});
								rollingInterval = setInterval('autoRolling()',5000);
								$(this).addClass('pauseType');
							}
						});
					});
					
					
	function autoRolling(){
		var $obj = $('.rollingUl');
		var maxRollingNum = $obj.find('li').length;
		var nextNum = rollingNum + 1;
			
			if(nextNum == maxRollingNum){
				nextNum = 0;
			}
				$obj.find('li').fadeOut('200');
				$obj.find('li').eq(nextNum).fadeIn('500');
				rollingNum = nextNum;
		}
//자동롤링기능 끝//		
		

		
//하단베너 이벤트 시작//



function autoRollingCoupon(){
						var $obj = $('.rollingCouponUl');
						var maxRollingNum = $obj.find('li').length;
						var nextNum = rollingCouponNum + 1;
						if(nextNum == maxRollingNum){
							nextNum = 0;
						}
						$obj.find('li').fadeOut('200');
						$obj.find('li').eq(nextNum).fadeIn('500');
						rollingCouponNum = nextNum;
					}
					function autoRollingCouponPrev(){
						var $obj = $('.rollingCouponUl');
						var maxRollingNum = $obj.find('li').length;
						var nextNum = rollingCouponNum - 1;
						if(nextNum == maxRollingNum){
							nextNum = 0;
						}
						$obj.find('li').fadeOut('200');
						$obj.find('li').eq(nextNum).fadeIn('500');
						rollingCouponNum = nextNum;
					}
					function autoRollingCouponNext(){
						var $obj = $('.rollingCouponUl');
						var maxRollingNum = $obj.find('li').length;
						var nextNum = rollingCouponNum + 1;
						if(nextNum == maxRollingNum){
							nextNum = 0;
						}
						$obj.find('li').fadeOut('200');
						$obj.find('li').eq(nextNum).fadeIn('500');
						rollingCouponNum = nextNum;
					}
					$('.btnBannerPrev').bind('click',function(){
						autoRollingCouponPrev();
						return false;
					});
					$('.btnBannerNext').bind('click',function(){
						autoRollingCouponNext()
						return false;
					});




var zIndexNum = 1;
		$(document).ready(function(){
			$('.openBtn').bind('click',function(){
				var clickedNext = $(this).next().css('display');
				var plusZindexNum = zIndexNum + 1;
				$(this).parent().css('z-index',plusZindexNum);
//				$(this).next().css('z-index',1);
				if(clickedNext == 'none'){
					$(this).next().stop();
					$(this).next().slideDown(500);
				}
				zIndexNum = plusZindexNum;
				var thisSrc = $(this).find('img').attr('src');
				$(this).find('img').attr('src',thisSrc.replace('1.gif','2.gif'));
				var closeSrc = $(this).next().next().find('img').attr('src');
				$(this).next().next().find('img').attr('src',closeSrc.replace('2.gif','1.gif'));
				return false;
			});
			$('.closeBtn').bind('click',function(){
				$(this).prev().slideUp(500);
				var thisSrc = $(this).find('img').attr('src');
				$(this).find('img').attr('src',thisSrc.replace('1.gif','2.gif'));
				var closeSrc = $(this).prev().prev().find('img').attr('src');
				$(this).prev().prev().find('img').attr('src',closeSrc.replace('2.gif','1.gif'));
				return false;
			});
		});

//하단베너 이벤트 끝///
		
		
//배너 및 하단 메뉴 	//
 	
				var nowNoticeNum = 0;
				var maxFootNotice = $('.footNoticeUl li').length;
				$(document).ready(function(){
					$('.goUp').bind('click',function(){
						var plusNum = nowNoticeNum + 1;
						if(plusNum == maxFootNotice){
							plusNum = maxFootNotice-1;
						}
						$('.footNoticeUl').animate({
							'top': -19 * plusNum +'px'
						},500);
						nowNoticeNum = plusNum;
						return false;
					});
					$('.goDown').bind('click',function(){
						var minusNum = nowNoticeNum - 1;
						if(minusNum == -1){
							minusNum = 0;
						}
						$('.footNoticeUl').animate({
							'top': -19 * minusNum +'px'
						},500);
						nowNoticeNum = minusNum;
						return false;
					});

					$('.btn_ria_insta').click( function (){
						$('.ria_instar').css('display','block');
					});
					$('.ria_instar.close').click( function (){
						$('.ria_instar').css('display','none');
					});
				});
		
//배너 및 하단 메뉴 끝	//
		
		