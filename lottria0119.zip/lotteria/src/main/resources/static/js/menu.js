/**
 * 
 */

$(function(){

	$("#navigation>.wrap .menu .depth1").hover(function(){
		$("#sub-menu").show();
	},function(){
		$("#sub-menu").hide();
	});
	
	$("#sub-menu").hover(function(){
		$(this).show();
	},function(){
		$(this).hide();
	});
	
});