package nowon.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Table(name = "ncs_board")
@Entity//DB 와 매핑되는 클래스
public class BoardEntity extends BaseEntity{// Repository 접근가능
	//게시판 사용을 위한 DB
	//HeidiSQL 데이터베이스를 사용하기위해 만든 클래스.
	//테이블이름은 ncs_board 로 만들어진다.
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long no; //pk값.
	@Column(nullable = false)
	private String subject; //제목
	@Column(nullable = false)
	private String content; //내용
	@Column(nullable = false)
	private String writer; //작성자
	private int readCount; //작성일
	
	public BoardEntity update(String subject, String content) {
		this.subject=subject;
		this.content=content;
		return this;
	}
	
}
