package nowon.security;

import java.util.Collection;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.oauth2.core.user.OAuth2User;

import lombok.Getter;
import nowon.domain.entity.MemberEntity;

@Getter
public class MyUserDetails extends User implements OAuth2User{

	private String name;
	private boolean isSocail;
	
	private Map<String, Object> attributes;
	
	public MyUserDetails(MemberEntity entity) {
		super(
				entity.getEmail(),     	     //username 
				entity.getPassword(),        //password
				entity.getRoleSet().stream() //Role
									.map(role-> new SimpleGrantedAuthority(role.getRole()))
									.collect(Collectors.toSet()));
		
		//role은 Set콜랙션의 구성으로 GrantedAuthority타입을 요구: 
		//Set<MemberRole> -> Set<SimpleGrantedAuthority>
		//GrantedAuthority <- SimpleGrantedAuthority
		name=entity.getName();
		isSocail=entity.isSocial();
	}

	@Override
	public Map<String, Object> getAttributes() {
		// TODO Auto-generated method stub
		return attributes;
	}

}
