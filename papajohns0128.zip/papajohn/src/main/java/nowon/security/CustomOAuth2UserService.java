package nowon.security;

import java.util.Map;
import java.util.Optional;

import org.springframework.security.config.oauth2.client.CommonOAuth2Provider;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import nowon.domain.entity.MemberEntity;
import nowon.domain.entity.MemberEntityRepository;

@RequiredArgsConstructor
@Service
public class CustomOAuth2UserService extends DefaultOAuth2UserService{
	
	private final PasswordEncoder passwordEncoder;
	private final MemberEntityRepository memberEntityRepository;
	
	@Override
	public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
		OAuth2User oauth2User = super.loadUser(userRequest);
		//default 인증완료
		String registrationId= userRequest.getClientRegistration().getRegistrationId();
		
		
		Map<String, Object> map= oauth2User.getAttributes();
		for(String key :map.keySet()) {
			System.out.println(key+":" +map.get(key)); 
			
		}
		
		//MyUserDetails //일반유저
		//Default
		return saveSocailUser(registrationId, oauth2User);
	}

	private OAuth2User saveSocailUser(String registrationId, OAuth2User oauth2User) {
		String email=null;
		String name=null;
		if(registrationId.equals("google")) {
			email=oauth2User.getAttribute("email");
			name=oauth2User.getAttribute("name");
		}else if(registrationId.equals("naver")) {
			
		}
		
		//가입여부 체크
		Optional<MyUserDetails> check=memberEntityRepository.findById(email)
				.map(MyUserDetails::new);
		if(check.isPresent()) {
			return check.get();
		}
		
		//가입이 안되어있으면 소셜정보 회원가입처리
		MemberEntity entity=MemberEntity.builder()
				.email(email).name(name).isSocial(true)
				.password(passwordEncoder.encode("socailuser"+System.currentTimeMillis()) )
				.build();
		entity.addRole(MemberRole.USER);
		// MyUserDetails //일반유저
		
		MemberEntity result= memberEntityRepository.save(entity);
		MyUserDetails myUserDetails=new MyUserDetails(result);
		
		return myUserDetails;
	}

	
	

}
