package nowon.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import lombok.RequiredArgsConstructor;
import nowon.domain.dto.member.MemberSaveDto;
import nowon.service.SignUpService;
import nowon.service.impl.SignUpServiceImpl;

@RequiredArgsConstructor
@Controller
public class LogController {
	
	final SignUpService signService; 
	//1.회원가입처리를 위해 service 인터페이스, serviceImpl 클래스 만들어준다.
	//4. SignUpServiceImpl 에서 회원가입기능을 구현하면 된다.
	
	//로그인페이지 이동
	@GetMapping("/log/page") //get방식은 어떤정보를 가져와 조회하는 방식, post방식은 데이터를 제출,수정하기위해 데이터를 전송하는방식
	public String loginPage() {
		return "log/login";
	}
	
	//회원가입페이지 이동
	@GetMapping("/log/signup")
	public String singupPage() {
		return "/log/signup";
	}
	
	//회원가입처리 
	@PostMapping("/log/signup") //signup.html 여기서 정보를 받음.
	public String singup(MemberSaveDto dto) {
		
		signService.save(dto); //-> 사용자에게 입력받은 정보를 저장!
		//dto 클래스= 데이터 전송을 도와주는 객체
		//dto 클래스=DB의 정보를 service, controller 에다 보낼때 사용하는 객체!
		
		//2.사용자가 회원가입을 위해 입력한 정보를 MemberSaveDto로 데이터를 보냄,
		//3.MemberSaveDto 클래스를 만든다.
		
		return "/log/login"; //처리후 로그인페이지로 이동
	}
	
}
