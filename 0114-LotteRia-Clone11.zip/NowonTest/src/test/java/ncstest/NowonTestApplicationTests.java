package ncstest;

import java.util.List;
import java.util.stream.IntStream;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.annotation.Commit;

import lombok.extern.log4j.Log4j2;
import ncstest.domain.entity.BoardEntity;
import ncstest.domain.entity.BoardEntityRepository;
import ncstest.domain.entity.MemberEntity;
import ncstest.domain.entity.MemberEntityRepository;
import ncstest.security.MemberRole;

@Log4j2
@SpringBootTest
class NowonTestApplicationTests {

	@Autowired
	MemberEntityRepository memberEntityRepository;
	@Autowired
	PasswordEncoder passwordEncoder;
	@Autowired
	BoardEntityRepository boardEntityRepository;
	
	@Test
	void 더미데이터입력테스트() {
		IntStream.rangeClosed(1, 10).forEach(i->{
			MemberEntity memberEntity=MemberEntity.builder()
					.email("test"+i+"@test.com")
					.password(passwordEncoder.encode("1111"))
					.name("test"+i)
					.build();
			memberEntity.addRole(MemberRole.USER);
			memberEntityRepository.save(memberEntity);
			
			BoardEntity entity=BoardEntity.builder()
					.subject("제목 테스트 "+i)
					.content("내용 테스트 "+i)
					.writer(memberEntity.getName())
					.build();
			boardEntityRepository.save(entity);
		});
		
	}
	
	//@Test
	void board입력테스트() {
		IntStream.rangeClosed(1, 1).forEach(i->{
			BoardEntity entity=BoardEntity.builder()
					.subject("제목테스트" + i)
					.content("내용테스트" + i)
					.writer("작성자" + i)
					.build();
			boardEntityRepository.save(entity);
			log.info("test");
		});
	}
	
	//@Test
	void board모두읽어오기테스트() {
		List<BoardEntity> list=boardEntityRepository.findAll();
		log.info("읽어오기 테스트"+list);
	}
	
	@Transactional
	@Commit
	//@Test
	void board수정테스트() {
		BoardEntity result=boardEntityRepository.findById(11L)
				.map(e->e.update("제목수정", "내용수정"))
				.orElse(null);
	}
	
	//@Test
	void board삭제() {
		//11번 삭제
		long bno=11;
		boardEntityRepository.deleteById(bno);
		log.info(bno + "11 삭제완료!");
	}
}
