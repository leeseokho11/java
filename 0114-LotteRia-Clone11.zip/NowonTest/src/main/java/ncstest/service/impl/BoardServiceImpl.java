package ncstest.service.impl;

import org.springframework.stereotype.Service;

import ncstest.service.BoardService;

@Service
public class BoardServiceImpl implements BoardService{

}
