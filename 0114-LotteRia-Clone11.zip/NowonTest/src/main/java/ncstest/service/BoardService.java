package ncstest.service;

public interface BoardService {

}
