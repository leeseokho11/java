package nowon.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import nowon.domain.dto.visual.SaveDto;

public interface VisualService {

	void saveAndFileUpload(MultipartFile visualFile, SaveDto dto) throws IOException;

}
