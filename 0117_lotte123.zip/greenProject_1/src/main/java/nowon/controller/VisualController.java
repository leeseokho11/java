package nowon.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import nowon.domain.dto.visual.SaveDto;
import nowon.service.VisualService;
import nowon.service.impl.VisualServiceImpl;

@Controller
public class VisualController {
	
	VisualService service;
	
	@GetMapping("/admin/visualpage")
	public String visualpage() {
		return "/admin/visual/write";
	}
	
	@PostMapping("/admin/visuals")
	public String Save(MultipartFile visualFile, SaveDto dto) {
		System.out.println(visualFile);
		return service.saveAndFileUpload(visualFile, dto);
	}
}
