package the.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import the.domain.dto.goods.Goods;
import the.service.GoodsService;
import the.service.impl.GoodsServiceImpl;

@Controller
public class GoodsController {
	
	@Autowired
	private GoodsService service;
	
	@GetMapping("/goods")
	public String list() {
		return "goods/list";
	}
	
	@GetMapping("/goods/write")
	public String write() {
		return "goods/write";
	}
	
	
	@PostMapping("/goods")
	public String write(Goods dto, MultipartFile file) {
		return service.saveAndImgUpload(dto, file);
	}
}
