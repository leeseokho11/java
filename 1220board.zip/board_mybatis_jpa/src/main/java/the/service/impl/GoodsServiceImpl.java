package the.service.impl;

import java.io.File;
import java.io.IOException;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import the.domain.dto.file.GoodsFileDto;
import the.domain.dto.goods.Goods;
import the.mapper.GoodsFileMapper;
import the.mapper.GoodsMapper;
import the.service.GoodsService;

@RequiredArgsConstructor
@Service
public class GoodsServiceImpl implements GoodsService {
	
	final GoodsMapper goodsMapper;
	final GoodsFileMapper goodsFileMapper;
	
	@Override
	public String saveAndImgUpload(Goods dto, MultipartFile file) {
		//1. 상품정보 저장
		goodsMapper.save(dto);
		//pk값은 Goodsdto.no 저장된 상태
		
		//2. 이미지 정보 저장 , upload 
		String fileName=file.getOriginalFilename();
		String fileURI="/images/goods/";
		long fileSize=file.getSize();
		
		GoodsFileDto goodsFileDto=GoodsFileDto.builder()
				.fileName(fileName)
				.fileURI(fileURI)
				.fileSize(fileSize)
				.gno(dto.getNo()) //fk 넣어서 입력
				.build();
		goodsFileMapper.save(goodsFileDto); //상품이미지 저장
		
		ClassPathResource cpr=new ClassPathResource("static" +fileURI);
		
		try {
			file.transferTo(new File(cpr.getFile() , fileName ));
			System.out.println("파일업로드완료");
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return "redirect:/goods";
	}

}
