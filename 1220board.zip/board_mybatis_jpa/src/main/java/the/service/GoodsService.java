package the.service;

import org.springframework.web.multipart.MultipartFile;

import the.domain.dto.goods.Goods;

public interface GoodsService {

	String saveAndImgUpload(Goods dto, MultipartFile file);

}
