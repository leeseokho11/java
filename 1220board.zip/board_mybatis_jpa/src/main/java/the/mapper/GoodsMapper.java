package the.mapper;

import org.apache.ibatis.annotations.Mapper;

import the.domain.dto.goods.Goods;

@Mapper
public interface GoodsMapper {

	void save(Goods dto);

}
