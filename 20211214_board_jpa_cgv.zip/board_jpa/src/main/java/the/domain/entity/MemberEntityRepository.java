package the.domain.entity;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface MemberEntityRepository extends JpaRepository<MemberEntity, Long> {

	Optional<MemberEntity> findByEmail(String string);

	//void deleteByNo(long l);
	//쿼리메서드 만들어서 사용합니다.
	//find..By, read...By, count..By, get..By 로 시작해야한다.
	//쿼리가 복잡한경우 @Query 어노테이션 사용가능 JPQL문법 작성하여 가능
	
	
	
}
