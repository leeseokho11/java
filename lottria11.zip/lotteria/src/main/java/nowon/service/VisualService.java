package nowon.service;

import java.io.IOException;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import nowon.domain.dto.visual.SaveDto;

public interface VisualService {

	void saveAndFileUpload(MultipartFile visualFile, SaveDto dto)throws IOException;

	String getlist(Model model);

	String getPageList(Model model);

}
