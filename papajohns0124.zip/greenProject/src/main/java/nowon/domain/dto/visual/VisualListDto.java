package nowon.domain.dto.visual;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.NoArgsConstructor;
import nowon.domain.entity.Visual;


@NoArgsConstructor
@Data
public class VisualListDto{
	
	private long vno;
	private String filePath;
	private String fileName;
	private long fileSize;
	private String title;
	private String subTitle;
	private int orderNo;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	public VisualListDto(Visual e) {
		this.vno = e.getVno();
		this.filePath = e.getFilePath();
		this.fileName = e.getFileName();
		this.fileSize = e.getFileSize();
		this.title = e.getTitle();
		this.subTitle = e.getSubTitle();
		this.orderNo = e.getOrderNo();
		this.createdDate = e.getCreatedDate();
		this.updatedDate = e.getUpdatedDate();
	}
	
	

}
