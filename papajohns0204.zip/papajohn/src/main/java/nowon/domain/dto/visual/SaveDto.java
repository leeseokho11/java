package nowon.domain.dto.visual;

import lombok.Data;

@Data
public class SaveDto {
	
	private String title;
	private String subTitle;
	
}
