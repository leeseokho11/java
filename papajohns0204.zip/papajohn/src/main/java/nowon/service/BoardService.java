package nowon.service;

import org.springframework.ui.Model;

import nowon.domain.dto.member.BoardSaveDto;

public interface BoardService {

	String eventList(int page, Model model);

	String eventListAll(Model model);

	String save(BoardSaveDto saveDto);

}
