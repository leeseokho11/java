package nowon.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import lombok.RequiredArgsConstructor;
import nowon.domain.dto.member.BoardListDto;
import nowon.domain.dto.member.BoardSaveDto;
import nowon.domain.dto.member.PageDto;
import nowon.domain.entity.BoardEntity;
import nowon.domain.entity.BoardEntityRepository;
import nowon.service.BoardService;

@RequiredArgsConstructor
@Service
public class BoardServiceImpl implements BoardService{
	
	final BoardEntityRepository repository;
	
	
	//게시글 목록 페이지처리
	
	@Override
	public String eventList(int page, Model model) {
		
		int size=7;
		
		Sort sort=Sort.by(Direction.DESC, "no");
		Pageable pageable=PageRequest.of(page-1, size, sort);
		
		Page<BoardEntity> result=repository.findAll(pageable);
		
		model.addAttribute("pd", new PageDto(5, page, result.getTotalPages()));
		
		List<BoardListDto> dto=result.getContent().stream()
				.map(BoardListDto::new)
				.collect(Collectors.toList());
		
		model.addAttribute("list", dto);
		return "board2/list2";
	}
	
	
	//게시글 조회
	@Override
	public String eventListAll(Model model) {
		Sort sort=Sort.by(Direction.DESC, "no");
		List<BoardListDto> list=repository.findAll(sort).stream()
				.map(BoardListDto::new)
				.collect(Collectors.toList());
		
		model.addAttribute("list",list);
		return "board2/list2";
	}
	
	//이벤트 -> 커뮤니티 글쓰기 기능처리
	@Override
	public String save(BoardSaveDto saveDto) {
		
		repository.save(saveDto.toEntity()); //dto->entity로 매핑한것에서 entity로만 저장
		
		return "redirect:/board2";
	}

}
