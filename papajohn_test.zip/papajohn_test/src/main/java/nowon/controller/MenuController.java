package nowon.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MenuController {
	
	//메뉴페이지 이동
	@GetMapping("/layout/menu")
	public String MenuPage() {
		return "layout/menu";
	}
}
