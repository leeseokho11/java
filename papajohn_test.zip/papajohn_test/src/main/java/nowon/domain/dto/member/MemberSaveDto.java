package nowon.domain.dto.member;

import lombok.Data;

@Data
public class MemberSaveDto {
	//LogController 에서 회원가입처리를 위해 입력받을 사용자의 이메일,비번,이름의 정보를 받는다.
	private String email;
	private String password;
	private String name;
	
}
