package nowon.config;


import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.oauth2.client.CommonOAuth2Provider;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.PlatformTransactionManager;

import nowon.security.CustomOAuth2UserService;


@EnableWebSecurity //스프링 시큐리티를 사용하기 위한 어노테이션
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter { //WebSecurityConfigurerAdapter 상속받음
	
	@Lazy
	@Autowired
	private CustomOAuth2UserService customOAuth2UserService;
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	//security 규칙
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http.authorizeHttpRequests()
			.antMatchers("/", "/log/**","/boards*/**","/layout/**","/board/**","/board2/**").permitAll()//인증필요없이 누구나 접근가능
			.antMatchers("/visuals*/**","/file/**").permitAll()//인증필요없이 누구나 접근가능
			.antMatchers("/member/**").hasRole("USER") 
			.antMatchers("/admin/**").hasRole("ADMIN") //admin이라는 롤을 가진 사용자만 접근가능
			.anyRequest().authenticated();//나머지주소는 인증을 받아야합니다.
		
		http.formLogin() // /login 설정처리
			.loginPage("/log/page") //따로만든 로그인페이지가 있어서 그걸로 사용하겠다는 뜻
			.loginProcessingUrl("/login/proc")//로그인페이지 의 action
			.usernameParameter("email")//로그인 페이지 username -> email
			.defaultSuccessUrl("/") //정상적으로 인증되면 이동할 페이지 설정
			;
		http.oauth2Login().userInfoEndpoint().userService(customOAuth2UserService);
		//인증을위한 AuthenticationManager 인증처리를 한다.
		//실제처리시 UsernamePasswordAuthenticationToken 토큰이라는 이름으로 전달
		//UsernamePasswordAuthenticationFilter 내부에서 authenticate()에 파라미터로 전달
		//AuthenticationProvider provider; //DaoAuthenticationProvider
		//UserDetailsService : usercheck
		http.csrf().disable(); //csrf 사용하지 않음
	}
	
	//security 규칙을 무시하게 하는 uri 규칙(여기 등록하면 규칙 적용하지않음)
	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring()
			.antMatchers("favicon.ico*")
			.antMatchers("/images/**")
			.antMatchers("/js/**")
			.antMatchers("/log/signup")
			.antMatchers("/css/**");
	}


	/*
	 * @Bean public PasswordEncoder passwordEncoder() { return new
	 * BCryptPasswordEncoder(); }
	 */
	
	
/*
	@Bean(name = "transactionManager")
	public PlatformTransactionManager dataPlatformTransactionManager(DataSource dataSource) {
		return new DataSourceTransactionManager(dataSource);
	}
	//*/
}
