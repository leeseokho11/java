package nowon.service;

import nowon.domain.dto.member.MemberSaveDto;

public interface SignUpService {

	void save(MemberSaveDto dto);

}
