package nowon.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import nowon.domain.dto.member.MemberSaveDto;
import nowon.domain.entity.MemberEntity;
import nowon.domain.entity.MemberEntityRepository;
import nowon.security.MemberRole;
import nowon.service.SignUpService;

@Service
public class SignUpServiceImpl implements SignUpService {
	
	@Autowired
	MemberEntityRepository repository; 
	//사용할 DB 객체(클래스)를 여기로 가져와야한다.  
	//미리 만들어놓은 MemberEntityrepository 사용해서 웹페이지(html)와 내부서버(DB)를 연결하기위해  repository 사용!
	//MemberEntity에는 사용자로부터 받은 email,name,password 가 DB(HeidSQL)에 저장됨.
	
	@Autowired
	PasswordEncoder passwordEncoder; //비밀번호 인코딩
	
	//회원가입처리 기능구현
	@Override
	public void save(MemberSaveDto dto) {
		
		//회원가입할때 사용자의 정보를 DB에 저장해야한다.
		// 미리 만들어놓은 MemberEntity(DB정보)를 사용자의 입력받을 email,name,password 연결(매핑)시킨다.
		// repository를 통해 입력받은(사용자정보)를 save(entity)를 통해 저장한다.
		
		MemberEntity entity=MemberEntity.builder() //-> 웹페이지(회원가입페이지)의 사용자가 입력한 정보를 조회
				.email(dto.getEmail())
				.name(dto.getName())
				.password(passwordEncoder.encode(dto.getPassword()))
				.build();
		
		
		entity.addRole(MemberRole.USER); 
		//config의 security 사용때문에 Enum클래스의 사용자(user)를 정의해준다.
		
		repository.save(entity); //사용자의 입력 정보를 저장.
	}

}
