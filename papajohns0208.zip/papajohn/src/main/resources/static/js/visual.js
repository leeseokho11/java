/** 
* 작성자 : 조재청 
* 작성일 : 2020/01/14 
*/ 
var myTimeout; 
var speed=400;
var imgSize=1920; 
var delay=3000; 
var images; 
var flag=0;


$(function(){ 
	dbImgLoading();
});
function dbImgLoading(){
	$.ajax({
		url: "/visuals",
		success: function(result){
			$("#visual>.visual-area").html(result);
			//태그가 완성된이후에 처리해야함..
		}
	});
}
//브라우저 최소화되었을때 타이머 스톱
document.addEventListener("visibilitychange", function() {
	console.log( document.visibilityState );
	if(document.visibilityState=="hidden"){ stop(); }else{ start(); }
});

