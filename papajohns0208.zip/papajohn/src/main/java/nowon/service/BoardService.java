package nowon.service;

import org.springframework.ui.Model;

import nowon.domain.dto.member.BoardSaveDto;
import nowon.domain.dto.member.BoardUpdateDto;

public interface BoardService {

	String save(BoardSaveDto saveDto);

	String listAll(Model model); //게시글 목록

	String detail(long no, Model model); //상세페이지 이동

	String delete(long no); //게시글 삭제

	String update(long no, BoardUpdateDto dto); //게시글 업데이트

}
