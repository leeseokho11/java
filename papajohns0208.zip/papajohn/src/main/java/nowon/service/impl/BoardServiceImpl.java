package nowon.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import lombok.RequiredArgsConstructor;
import nowon.domain.dto.member.BoardDetailDto;
import nowon.domain.dto.member.BoardListDto;
import nowon.domain.dto.member.BoardSaveDto;
import nowon.domain.dto.member.BoardUpdateDto;
import nowon.domain.dto.member.PageDto;
import nowon.domain.entity.BoardEntity;
import nowon.domain.entity.BoardEntityRepository;
import nowon.service.BoardService;

@RequiredArgsConstructor
@Service
public class BoardServiceImpl implements BoardService{
	
	final BoardEntityRepository repository;
	
	

	//게시글 조회
	@Override
	public String listAll(Model model) {
		Sort sort=Sort.by(Direction.DESC, "no");//sort객체로 게시글정렬방식
		
		List<BoardListDto> list=repository.findAll(sort).stream()
				.map(BoardListDto::new)
				.collect(Collectors.toList());
		
		model.addAttribute("list",list);
		return "/board2/list2";
	}
	
	
	//이벤트 -> 커뮤니티 글쓰기 기능처리
	@Override
	public String save(BoardSaveDto saveDto) {
		
		repository.save(saveDto.toEntity()); //dto->entity로 매핑한것에서 entity로만 저장
		
		return "redirect:/board2/list2";
	}

	//이벤트 -> 커뮤니티 상세페이지 처리
	@Transactional
	@Override
	public String detail(long no, Model model) {
		// 1. pk값을 이용해 게시글 조회
		// DB에 동일 레코드가 존재하면 수정처리: 모든컬럼 수정
		//BoardEntity entity=repository.findById(no).get().updateReadCount();
		//pk를 이용해 레코드 존재확인, 조회수 
		
		//repository.save(entity);
		
		BoardDetailDto dto=repository.findById(no)
				.map(e->e.updateReadCount())
				.map(BoardDetailDto::new)
				.orElseThrow();
		
		//model객체를 통해 detailDto DB정보를 가져온다.
		// "detail" 은 이름정의 
		model.addAttribute("detail",dto);
		
		return "/board2/detail";
	}

	// 이벤트 -> 커뮤니티 게시글 삭제
	@Override
	public String delete(long no) {
		repository.deleteById(no);
		return "redirect:/board2/list2"; //삭제처리후 사용자에게 보여줄페이지(list2)로 이동 
	}

	// 이벤트 -> 커뮤니티 게시글 업데이트
	@Transactional
	@Override
	public String update(long no, BoardUpdateDto dto) {
		
		repository.findById(no).map(e->e.update(dto));
		
		return "redirect:/board2/list2/"+no;
	}


}
