package nowon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.filter.HiddenHttpMethodFilter;

//@EnableTransactionManagement
@EnableJpaAuditing
@SpringBootApplication
public class PapajohnApplication {

	public static void main(String[] args) {
		SpringApplication.run(PapajohnApplication.class, args);
	}
	/*
	 * @Bean HiddenHttpMethodFilter hiddenHttpMethodFilter() { return new
	 * HiddenHttpMethodFilter(); }
	 */
}
