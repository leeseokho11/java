package nowon.domain.dto.member;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import nowon.domain.entity.BoardEntity;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
public class BoardDetailDto {
	//DB에서 가져올 상세페이지 정보
	
	private long no; //pk값
	private String subject; //제목
	private String content; //내용
	private String writer; //작성자
	private int readCount; //
	private LocalDateTime createdDate; //작성일
	
	//BoardEntity 객체의 필드값(내용들을) -> BoardDetailDto 필드로 매핑
	//using fields
	public BoardDetailDto(BoardEntity entity) {
		
		this.no = entity.getNo();
		this.subject = entity.getSubject();
		this.content = entity.getContent();
		this.writer = entity.getWriter();
		this.readCount = entity.getReadCount();
		this.createdDate = entity.getCreatedDate();
	}
	
	
	
}
