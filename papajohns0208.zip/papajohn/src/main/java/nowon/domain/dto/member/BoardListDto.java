package nowon.domain.dto.member;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import nowon.domain.entity.BoardEntity;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
public class BoardListDto {
	//이벤트 -> 커뮤니티  
	
	private long no;
	private String subject;
	private String writer;
	private int readCount;
	private LocalDateTime createdDate;
	
	//using flid
	public BoardListDto(BoardEntity entity) {
		
		this.no = entity.getNo();
		this.subject = entity.getSubject();
		this.writer = entity.getWriter();
		this.readCount = entity.getReadCount();
		this.createdDate = entity.getCreatedDate();
	}
	
	
}
