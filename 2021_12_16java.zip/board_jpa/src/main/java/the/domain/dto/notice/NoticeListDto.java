package the.domain.dto.notice;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import the.domain.entity.Notice;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
public class NoticeListDto {
	
	private long no;
	private String subject;
	private String content;
	private int readCount;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	// notice -> dto 역할
	public NoticeListDto(Notice notice) {
		
		this.no = notice.getNo();
		this.subject = notice.getSubject();
		this.content = notice.getContent();
		this.readCount = notice.getReadCount();
		this.createdDate = notice.getCreatedDate();
		this.updatedDate = notice.getUpdatedDate();
	}
	
	
}
