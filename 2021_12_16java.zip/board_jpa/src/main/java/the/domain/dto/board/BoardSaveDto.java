package the.domain.dto.board;

import lombok.Setter;
import lombok.ToString;
import the.domain.entity.BoardEntity;

@ToString
@Setter
public class BoardSaveDto {
	
	private String subject;
	private String content;
	private String writer;
	
	//dto-> entity 로 매핑
	public BoardEntity toEntity() {
		return BoardEntity.builder()
				.subject(subject).content(content).writer(writer)
				//.createdDate(LocalDateTime.now())
				.build();
	}
	
}
