package the.domain.dto.notice;

import lombok.Setter;
import lombok.ToString;
import the.domain.entity.Notice;

@ToString
@Setter
public class NoticeSaveDto {
	
	String subject;
	String content;
	
	
	public Notice toNotity() {
		return Notice.builder()
				.subject(subject).content(content)
				.build();
	}
}
