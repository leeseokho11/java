package the.domain.dto.faq;

import java.time.LocalDateTime;

import lombok.Getter;
import the.domain.entity.Division;
import the.domain.entity.FaqEntity;

@Getter
public class FaqListDto {
	private long no;
	private Division division;
	private String subject;
	private String content;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	//entity ->dto 로 매핑해주는 생성자
	public FaqListDto(FaqEntity e) {
		
		this.no = e.getNo();
		this.division = e.getDivision();
		this.subject = e.getSubject();
		this.content = e.getContent();
		this.createdDate = e.getCreatedDate();
		this.updatedDate = e.getUpdatedDate();
	}
}
