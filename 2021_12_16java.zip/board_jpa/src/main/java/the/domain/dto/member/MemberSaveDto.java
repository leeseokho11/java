package the.domain.dto.member;

import lombok.Data;
import the.domain.entity.MemberEntity;

@Data
public class MemberSaveDto {
	private String email;
	private String password;
	private String name;
	
	//dto-> Entity클래스에 매핑해주는 메서드
	public MemberEntity toEntity() {
		return MemberEntity.builder()
				.email(email)
				.password(password)
				.name(name)
				.build();
	}
}
