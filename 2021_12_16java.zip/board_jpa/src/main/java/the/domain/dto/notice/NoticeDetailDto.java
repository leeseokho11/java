package the.domain.dto.notice;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import the.domain.dto.board.BoardDetailDto;
import the.domain.entity.BoardEntity;
import the.domain.entity.Notice;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
public class NoticeDetailDto {
	private long no;
	private String subject;
	private String content;
	private int readCount;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	//BoardEntity 객체의 필드값을 -> BoardDetailDto 필드로 매핑
	public NoticeDetailDto(Notice entity) {
		this.no = entity.getNo();
		this.subject = entity.getSubject();
		this.content=entity.getContent();
		this.readCount = entity.getReadCount();
		this.createdDate = entity.getCreatedDate();
		this.updatedDate = entity.getUpdatedDate();
	}
}
