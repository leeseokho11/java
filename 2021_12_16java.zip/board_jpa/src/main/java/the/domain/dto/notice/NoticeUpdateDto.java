package the.domain.dto.notice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter // -> 웹에서 넘어오는 데이터를 dto 에 매핑(입력데이터를 원하는 목적지에 전달)하기 위해 setter 메서드가 필요!
public class NoticeUpdateDto {
	private String subject;
	private String content;
	
	
}
