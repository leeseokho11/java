package the.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository // DAO기능
public interface BoardEntityRepository extends JpaRepository<BoardEntity, Long> {
	// 쿼리메서드  예)findByNo()
	// JpaRepository > PagingAndSortingRepository > CrudRepository > Repository
}
