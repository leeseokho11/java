package the.domain.entity;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface NoticeRepository extends JpaRepository<Notice, Long>{
	
	@Query("select n from Notice n where n.no between 21 and 30")
	List<Notice> getListAsOracle();
	
	
	/*
	@Query (
			"select * from (select ROWNUM rnum,n.*from(SELECT * from notice order by no DESC) n) where rnum BETWEEN" 
	List<Notice> getListAsOracle();
	*/
}
