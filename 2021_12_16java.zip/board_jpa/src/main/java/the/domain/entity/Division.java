package the.domain.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum Division { // class 가 아닌 enum 으로 만듬
	
	MOVIE("영화관이용"),
	LPOINT("L.POINT"),
	MEMBER("회원"),
	MEMBER_SHIP("맴버쉽"),
	ONLINE("온라인"),
	BENEFIT("할인"),
	TICKET("관람권"),
	STORE("스토어"),
	SPECAIL("스페셜관");
	
	private final String value;
	
}
