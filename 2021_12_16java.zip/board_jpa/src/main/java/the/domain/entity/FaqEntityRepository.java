package the.domain.entity;


import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FaqEntityRepository extends JpaRepository<FaqEntity, Long> {
	//division 컬럼을 where 절의 조건 컬럼으로 적용
	// orderby 정렬 연산자 No : no 컬럼을 정렬컬럼으로
	// 
	
	
	//List<FaqEntity> findByDivisionOrderByNoDesc(Division division);
	Page<FaqEntity> findByDivision(Division division, Pageable pageable);
	
	//And : findByIdAndPw(String id, String pw)
	//Or : findBySubjectOrContent(String subject, String content)
	// findById, findByIdIs, findByEquals  where id=?
	
	//Between : findByCreatedDateBetween(from, to) where between ? and ?
	
	//GreaterThan : findByNoGreaterThan(Long no) where no>?
	//GreaterThanEquals : >=
	//LessThan : findByNoGreaterThan(Long no) where no<?
	//LessThanEquals : <=
	//Afrer >
	//Before <
	
	
}
