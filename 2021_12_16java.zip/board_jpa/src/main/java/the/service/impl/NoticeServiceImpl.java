package the.service.impl;

import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import the.domain.dto.notice.NoticeDetailDto;
import the.domain.dto.notice.NoticeListDto;
import the.domain.dto.notice.NoticeSaveDto;
import the.domain.dto.notice.NoticeUpdateDto;
import the.domain.dto.util.PageDto;
import the.domain.entity.Notice;
import the.domain.entity.NoticeRepository;
import the.service.NoticeService;

@Service
public class NoticeServiceImpl implements NoticeService {
	
	@Autowired
	private NoticeRepository repository; //왜 필요한지 확인! repository=저장소
	
	
	//(12.16 오후시간)
	@Override
	public String getJpqlList(Model model, int page) {
		List<NoticeListDto> result=repository.getListAsOracle()
				.stream().map(NoticeListDto::new)
				.collect(Collectors.toList());
		
		model.addAttribute("list", result);
		
		EntityManager em;
		TypedQuery<Notice> query;
		
		return "notices/list";
	}
	
	//(12.16 오전시간) 공지사항 page 처리해서 list 읽어오기 
	@Override
	public String getPagelist(Model model, int page) {
		//int page=1; // 첫페이지가 0부터 세팅
		if(page<1)page=1;
		int size=5; //한 페이지에 표현할 갯수 (읽어올 공지사항 갯수)
		Pageable pageable=PageRequest.of(page-1, size, Direction.DESC, "no");
		//repository.findAll(pageable);
		
		//List<NoticeListDto> result=repository.findAll(pageable).map(NoticeListDto::new).getContent();
		
		Page<Notice> result=repository.findAll(pageable);
		List<NoticeListDto> list=result.map(NoticeListDto::new).getContent();
		
		System.out.println("총 페이지수 : " + result.getTotalPages());
		
		//페이지 번호 처리 (12.16 오후)
		
		
		int pageGroup=5; //한페이지에 표현할 수 있는 개수 -> 이런식으로 {1,2,3,4,5}, {6,7,8,9,10}
												//pageGroupNo    1            2
		
		/*
		int pageGroupNo=page / pageGroup; // 1/5(0) , 2/5(0), 3/5(0), 4/5(0), 5/5(1) -> 1그룹
		if(page % pageGroup > 0) pageGroupNo++; // if문을 통해 페이지 나누기 페이지그룹 했을때, 나머지가 0보다 크면  
		
		int pageTotal=result.getTotalPages();
		int to = pageGroup * pageGroup; // 마지막번호
		int from = to-pageGroup+1;   // 시작번호
		*/
		
		//PageDto pageDto;
		
		//페이지 번호 처리
		model.addAttribute("pd", new PageDto(pageGroup, page, result.getTotalPages())); // -> notices/list.html 에서 표현식 넣어준다(https://www.thymeleaf.org/참고)
		model.addAttribute("list", list);
		return "notices/list";
	}
	
	/*
	
	@Override //페이지 전체목록 (공지사항 페이지 1.방법)
	public String listAll(Model model) {
		Sort sort=Sort.by(Direction.DESC, "no");
		List<NoticeListDto> list= repository.findAll(sort).stream()
				.map(NoticeListDto::new)
				.collect(Collectors.toList());
		
		model.addAttribute("list",list);
		return "notices/list";
	}
	
	// 위에 listAll 방법처럼 안할거면 아래 for()방법으로 사용하면됨 
	
	@Override  (공지사항 페이지 2.방법)
	public String list(Model model) {
		Sort sort=Sort.by(Direction.DESC, "no");
		List<Notice> result=repository.findAll(sort);
		
		List<NoticeListDto> list=new Vector<>();
		for(Notice n:result) {
			NoticeListDto dto=NoticeListDto.builder()
					.no(n.getNo())
					.subject(n.getSubject())
					.readCount(n.getReadCount())
					.createdDate(n.getCreatedDate())
					.build();
			list.add(dto);
		}
		
		model.addAttribute("list",list);
		return "notices/list";
	}
	
	
	//listAll 에서 업그레이드된 페이지 넘기는 처리 (방법.3)
	@Override 
	public String listPage(int page, Model model) {
		
		int size=7;
		
		Sort sort=Sort.by(Direction.DESC, "no");
		Pageable pageable=PageRequest.of(page-1, size, sort);
		
		Page<Notice> result=repository.findAll(pageable);
		int pageTot=result.getTotalPages();
		
		int pageGroup=5;
		int pageGroupNo= page / pageGroup;
		if(page % pageGroup >0) pageGroupNo++;
		
		int to = pageGroupNo * pageGroup;
		int from = to - pageGroup +1;
		if(to > pageTot) to= pageTot;
		
		model.addAttribute("pages", IntStream.rangeClosed(from, to).toArray());
		model.addAttribute("to", to);
		model.addAttribute("from", from);
		model.addAttribute("pageTot", pageTot);
		
		List<NoticeListDto> dto = result.getContent().stream()
				.map(NoticeListDto::new).collect(Collectors.toList());
				
				
		model.addAttribute("list",dto);
		return "notices/list";
	}
	*/
	
	
	@Override //글쓰기 기능 처리
	public String save(NoticeSaveDto saveDto) {
		
		repository.save(saveDto.toNotity());
		
		return "redirect:/notices";
	}

	//디테일 페이지 처리, 조회수
	@Transactional
	@Override
	public String detailAndReadCount(long no, Model model) {
		
		
		NoticeDetailDto dto=repository.findById(no)
				.map(e->e.updateReadCount())
				.map(NoticeDetailDto::new)
				.orElseThrow();
		
		//model.addAttribute("detail", repository.findById(no).map(NoticeListDto::new).orElseThrow());
		model.addAttribute("detail",dto);
		return "notices/detail";
	}
	
	//수정
	@Transactional //(1,2)트렌젝션 적용
	@Override
	public String update(long no, NoticeUpdateDto dto) {
		//1. 트렌젝션 사용할지 말지 선택!
		//1. (1) 트렌젝션 미적용시 -> save() 
		// 문제가 발생하는 경우는 -> update대상만 entity객체에 셋팅해서 저장하면 나머지는 null or 0 등으로 같이 수정됨
		
		// 방법(1) 트렌젝션 미적용 
		// save(entity) 사용 -> NoticeUpdateDto 에 @getter/ public 만들어줘야됨
		//Notice entity=Notice.builder().no(no).subject(dto.getSubject()).content(dto.getContent()).build();
		//repository.save(entity); //no(pk) 가 DB에 존재하면 update
		//정상적으로 처리하기 위해 먼저 ID(pk)를 이용해서 먼저 수정할 원본 레코드가 읽어오자
		//그리고 수정할 정보만 수정하고 저장
		
		
		// 방법(1) 트렌젝션 미적용 
		//Notice entity=repository.findById(no).get(); //수정전 원본데이터
		//entity.updateSubjectAndContent(dto); // 원본 + update처리된 객체
		//repository.save(entity);
		//return "redirect:/notices/"+no;  //->  redirect:/notices/1 get매핑이 처리-> 상세페이지이동
		
		
		// 방법(2) 트렌젝션 사용 
		// map(e->e) 사용
		// repository.findById(no).map(e->{e.updateSubjectAndContent(dto);return null;});
		// return null 을 없애기위해 (domain.entity폴더에)notice 에서 public Notice 로 변경후 return this; 를 추가
		
		// 1.추가 후 아래처럼 사용
		//repository.findById(no).map(e->{return e.updateSubjectAndContent(dto);});
		
		// 2. 좀 더 간략하게 표현 
		repository.findById(no).map(e->e.updateSubjectAndContent(dto));
		return "redirect:/notices/"+no;
	}
	//삭제 -> 삭제처리가 가장 쉬움
	@Override
	public String delete(long no) {
		repository.deleteById(no); // -> 삭제기능
		return "redirect:/notices"; //->삭제후 리스트페이지로 이동
	}


	
}
