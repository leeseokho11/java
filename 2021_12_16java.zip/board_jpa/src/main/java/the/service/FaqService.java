package the.service;

import org.springframework.ui.Model;

public interface FaqService {

	String pagedList(int division, int page, Model model);

	

}
