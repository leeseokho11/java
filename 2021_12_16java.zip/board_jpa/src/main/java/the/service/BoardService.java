package the.service;

import org.springframework.ui.Model;

import the.domain.dto.board.BoardSaveDto;
import the.domain.dto.board.BoardUpdateDto;

public interface BoardService {

	String list(Model model);

	String listAll(Model model);

	String detail(long no, Model model);

	String delete(long no);

	String detailAndReadCount(long no, Model model);

	String update(long no, BoardUpdateDto dto);

	String listPage(int page, Model model);

	String save(BoardSaveDto saveDto);

}
