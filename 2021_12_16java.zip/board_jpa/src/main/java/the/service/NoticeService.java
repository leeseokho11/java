package the.service;

import org.springframework.ui.Model;

import the.domain.dto.notice.NoticeSaveDto;
import the.domain.dto.notice.NoticeUpdateDto;

public interface NoticeService {
	
	//String listAll(Model model); //공지사항 눌렀을때 나오는 딱 보여지는 전체 내용
	
	//String list(Model model); //공지사항 리스트 내용들 (ListAll과 같은방법)

	//String listPage(int page, Model model); //공지사항 밑에 페이지 1~ 숫자 누르면 내용바뀜

	String save(NoticeSaveDto saveDto); // 작성자가 쓴걸 저장할 내용들(글쓰기처리)

	String detailAndReadCount(long no, Model model); // (detail)상세페이지 처리

	String update(long no, NoticeUpdateDto dto);

	String delete(long no);

	String getPagelist(Model model, int page);

	String getJpqlList(Model model, int page);



	

	

	
	
}
