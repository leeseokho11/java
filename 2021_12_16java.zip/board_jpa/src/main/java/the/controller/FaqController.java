package the.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import lombok.RequiredArgsConstructor;
import the.domain.entity.Division;
import the.service.FaqService;
import the.service.impl.FaqServiceImpl;

@RequiredArgsConstructor
@Controller
public class FaqController {
	
	
	private final FaqService service; //생성자 초기화 ->@RequiredArgsConstructor
	
	// 페이지이동
	@GetMapping("/faq/{division}") 
	public String list(Model model, @RequestParam(defaultValue = "1")int page,
			@PathVariable int division) { //1. list 페이지로 감 //2. Model 객체가 있어야 넘겨준다.
		return service.pagedList(division,page,model); 
	}
}
