package the.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import the.domain.dto.notice.NoticeSaveDto;
import the.domain.dto.notice.NoticeUpdateDto;
import the.service.NoticeService;

@Controller
public class NoticeController {
	
	//service, serviceImpl 생성
	@Autowired
	private NoticeService service; //서비스 사용하기위해 만듬
	
	
	
	
	//공지사항 목록조회(전체,목록,페이지번호)조회 3가지를 list로 단계적으로 추가해서 표현
	//(12.16) ?page=1 Query String patameter  표현 ->@RequestParam
	@GetMapping("/notices")
	public String list(Model model, @RequestParam(defaultValue = "1") int page) {
		
		//return service.listPage(int page, Model model);
		//return service.getPagelist(model, page); //->(12.16) page 처리해서 list 읽어오기 -> getPagelist(model) 새로만듬
    //return service. 로 내가 아무렇게 이름을 짓고,  service에 정의 -> service에는 list 1개만 잇어도 무관
		
		//(12.16)
		return service.getJpqlList(model, page);
	}
	
	//글쓰기 페이지 처리
	@PostMapping("/notices") 
	public String save(NoticeSaveDto saveDto) {
		return service.save(saveDto);
	}
	
	//글쓰기 페이지 이동
	@GetMapping("notices-write")
	public String writePage() {
		return "notices/write";
	}
	
	//디테일 상세 페이지 
	@GetMapping("/notices/{no}") 
	public String detail(@PathVariable long no, Model model) {
		return service.detailAndReadCount(no, model);
	}
	
	//수정하기
	@PutMapping("/notices/{no}")                 //(NoticeUpdateDto) 제목,내용 파라미터 매핑
	public String update(@PathVariable long no, NoticeUpdateDto dto) {
		return service.update(no, dto);
	}
	
	//삭제하기
	@DeleteMapping("/notices/{no}")
	public String delete(@PathVariable long no) {
		return service.delete(no);
	}
	
	
}
//@get 조회, @post 생성
//@put 수정 @delete 삭제


//url              메서드   template 
//공지사항 목록        : /notices          get    notice/list.html
//공지사항 글쓰기페이지  : /notices/write   get    notice/write.html
//공지사항 글쓰기 처리  : /notices         post    redirect:/notices
//공지사항 상세페이지   : /notices/{글번호}   get    notice/detail.html
//공지사항 수정페이지   : /notices/{글번호}   Put    redirect:/notices/{글번호}
//공지사항 삭제페이지   : /notices/{글번호}   delete redirect:/notices