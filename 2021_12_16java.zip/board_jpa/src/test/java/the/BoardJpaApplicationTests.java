package the;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import the.domain.entity.BoardEntity;
import the.domain.entity.BoardEntityRepository;
import the.domain.entity.Division;
import the.domain.entity.FaqEntity;
import the.domain.entity.FaqEntityRepository;
import the.domain.entity.MemberEntity;
import the.domain.entity.MemberEntityRepository;
import the.domain.entity.Notice;
import the.domain.entity.NoticeRepository;

//@ExtendWith(SpringExtension.class)
@SpringBootTest//(webEnvironment = WebEnvironment.DEFINED_PORT)
class BoardJpaApplicationTests {
	
	@Autowired
	BoardEntityRepository  repository;
	
	@Autowired
	MemberEntityRepository memRepository;
	
	@Autowired //faq 테스트
	FaqEntityRepository faqRepository;
	
	@Autowired
	NoticeRepository noticeRepository;
	
	//@Test
		void 공지사항더미데이터() {
			IntStream.rangeClosed(21, 100000).forEach(i->{
				Notice entity=Notice.builder()
									.subject("공지제목 "+i)
									.content("공지내용 "+i)
									.build();
				
				noticeRepository.save(entity);
			});
		}
	
	
	//@Test
		void faqage적용일부만읽기() {
			Division div=Division.LPOINT;
			Sort sort=Sort.by(Direction.DESC, "no"); //no 컬럼 정렬
			Pageable pageable=PageRequest.of(0, 5, sort);
			List<FaqEntity> result= faqRepository.findByDivision(div, pageable).getContent();
			
			for(FaqEntity entity : result) {
				System.out.println(entity);
			}
		}
	
	
	
	//@Test
	/*	
	void faq데이터일부읽기() {
		Division div=Division.LPOINT;
		for(FaqEntity entity : faqRepository.findByDivisionOrderByNoDesc(div)) {
			System.out.println(entity);
		}
	}
	*/
	
	//@Test
	void faq데이터전체읽기() {
		for(FaqEntity entity : faqRepository.findAll()) {
			System.out.println(entity);
		}
	}
	
	//@Test
	void faq테스트() {
		Division d=Division.MOVIE;
		int i=d.ordinal();
		System.out.println("i :"+i);
		FaqEntity entity=FaqEntity.builder()
				.division(d)
				.subject(d.getValue()+ "제목")
				.content(d.getValue()+ "내용")
				.build();
		
		faqRepository.save(entity);
	}
	
	//@Test
	void faq임시데이터생성() {
	
		for(Division div : Division.values()) {
			for(int i=1; i<=10; i++) {
			FaqEntity entity=FaqEntity.builder()
					.division(div)
					.subject(div.name()+" 제목예제" +i)
					.content(div.name()+" 내용예제" +i)
					.build();
			
			faqRepository.save(entity);
			}
		}
		//faqRepository.save();
			
	}
		

	
	
	//@Test
	void 삭제() {
		repository.deleteById(321l);
	}
	
	@Transactional //: test에서 적용안됨
	@Rollback(false)
	//@Test
	void 멤버수정() {
		String newPassword="2222";
		MemberEntity result=memRepository.findByEmail("test01@test.com")
		//.map((e)->{return e.updatePassword(newPassword); })
		.map(e->e.updatePassword(newPassword))
		.get();
		
		//result.updatePassword(newPassword);
		System.out.println("수정후 멤버정보 : "+result);
		memRepository.save(result);
		
		//비밀번호 변경이되면 update_date 정보도 update됩니다.
	}
	
	//@Test 
	void 멤버읽어오기(){
		//MemberEntity result=memRepository.findById(1L).get();
		
		MemberEntity result=memRepository.findByEmail("test01@test.com").get();
		System.out.println("읽어온 결과 : "+result);
	}
	
	//@Test
	void 멤버삭제테스트() {
		memRepository.deleteById(2L);
		//memRepository.deleteByNo(1L);
	}
	//@Test
	void 멤버삽입테스트() {
		MemberEntity entity=MemberEntity.builder()
				.email("test02@test.com")
				.password("1234")
				.name("test02")
				.build();
		
		memRepository.save(entity);
	}
	
	//@Test
	void 데이터일괄저장테스트() {
		IntStream.rangeClosed(101, 300).forEach((i)->{
			repository.save(BoardEntity.builder()
					.subject("제목테스트"+i)
					.content("내용테스트"+i)
					.writer("작성자"+i)
					.createdDate(LocalDateTime.now())
					.build());
		});
	}
	//@Test
	void 더미데이터저장() {
		for(int i=1; i<=10; i++) {
			BoardEntity entity=BoardEntity.builder()
					.subject("제목테스트"+i)
					.content("내용테스트"+i)
					.writer("작성자"+i)
					.createdDate(LocalDateTime.now())
					.build();
			repository.save(entity);
		}
		
	}
	
	//@Test
	void 데이터읽기ID이용테스트() {
		//Optional<BoardEntity> result=repository.findById(1L);
		BoardEntity result=repository.findById(1L).get();
		System.out.println(result);
	}
	
	//@Test
	void 데이터읽기() {
		List<BoardEntity> result=repository.findAll();
		for(BoardEntity entity : result) {
			System.out.println(entity);
		}
	}
	
	

}
