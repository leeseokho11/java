/**
 * 
 */


$(function(){
	getWeather();
});

function getWeather(){
	var apiURI="";
	
	$.ajax({
		url: apiURI,
		dataType: "json",
		async:"false",
		success:function(result){
		temp=parseInt(parseFloat(result.main.temp)-273.15)+"";
		console.log("현재온도:" +parseInt(parseFloat(result.main.temp)-273.15));
		console.log(result);
		
		var imgURL = "http://openweathermap.org/img/w/" + result.weather[0].icon+""
		}
	});
}