package nowon.domain.dto.member;

import lombok.Setter;
import lombok.ToString;
import nowon.domain.entity.BoardEntity;

@ToString
@Setter
public class BoardSaveDto {
	//글쓰기 페이지에서 사용자가 입력한 내용 저장하는 Dto
	
	private String subject; //제목
	private String content; //내용
	private String writer; //작성자
	
	//dto-> entity로 매핑
	public BoardEntity toEntity() {
		return BoardEntity.builder()
				.subject(subject)
				.content(content)
				.writer(writer)
				.build();
	}
}
