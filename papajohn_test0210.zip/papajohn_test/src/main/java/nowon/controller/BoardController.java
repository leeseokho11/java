package nowon.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import nowon.domain.dto.member.BoardSaveDto;
import nowon.domain.dto.member.BoardUpdateDto;
import nowon.service.BoardService;

@RequiredArgsConstructor
@Log4j2
@Controller
public class BoardController {
	
	//게시판 기능
	final BoardService service;
	
	//이벤트 게시글 페이지 이동
	@GetMapping("/board/eventmenu")
	public String eventmenuPage() {
		return "/board/eventmenu";
	}
	
	//이벤트 -> 지난이벤트 페이지이동
	@GetMapping("/board/list")
	public String eventlistPage() {
		return "/board/list";
	}
	
	//이벤트 -> 커뮤니티 페이지이동
	@GetMapping("/board2/list2")
	public String listPage(Model model) {
		//게시글 목록을 DB에서 가져오기위해 model객체 사용
		return service.listAll(model);
	}
	
	
	//게시글 작성화면 이동
	@GetMapping("/board2/write")
	public String writePage() {
		log.debug("writePage() 실행!");
		return "board2/write";
	}
	
	//게시글 작성처리
	@PostMapping("/board2/list2")
	public String write(BoardSaveDto saveDto) {
		log.debug("write() 실행!");
		return service.save(saveDto);
	}
	
	//게시글 상세화면
	@GetMapping("/board2/list2/{no}")//list2(작성된게시글 목록중 사용자가 클릭시 no값으로 가져옴)
	public String detail(@PathVariable long no, Model model) {
		log.debug("detail() 실행!");
		return service.detail(no, model);
	}
	
	//게시글 상세화면 -> 수정
	@PutMapping("/board2/list2/{no}")
	public String update(@PathVariable long no, BoardUpdateDto dto) {
		log.debug("update() 실행!");
		return service.update(no, dto);
	}
	
	//deletemapping, putmapping사용하려면 hiddenmethod 사용
	//방법1.properties 에서  spring.mvc.hiddenmethod.filter.enabled=true 추가
	//방법2.PapajohnApplication 에서 @Bean , HiddenHttpMethodFilter 메서드 만들어야한다.
	
	//게시글 상세화면 ->  삭제
	@DeleteMapping("/board2/list2/{no}")
	public String delete(@PathVariable long no) {
		log.debug("delete() 실행!");
		return service.delete(no);
	}

}
