package nowon;

import java.util.stream.IntStream;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.annotation.Commit;

import lombok.extern.log4j.Log4j2;
import nowon.domain.entity.BoardEntity;
import nowon.domain.entity.BoardEntityRepository;
import nowon.domain.entity.MemberEntity;
import nowon.domain.entity.MemberEntityRepository;
import nowon.security.MemberRole;

@Log4j2
@SpringBootTest
class Papajohn_testApplicationTests {

	@Autowired
	MemberEntityRepository memberEntityRepository;
	@Autowired
	PasswordEncoder passwordEncoder;
	@Autowired
	BoardEntityRepository boardEntityRepository;
	
	//@Test
		void 관리자회원테스트() {
			/* 관리자회원가입 로직 구현하고 테스트하세요*/
			
			MemberEntity entity=MemberEntity.builder()
					.email("이석호@test.com")
					.password(passwordEncoder.encode("1234"))
					.name("이석호")
					.build();
			
			entity.addRole(MemberRole.USER);
			entity.addRole(MemberRole.ADMIN);
			memberEntityRepository.save(entity);
		}
	
	
	
	//@Test
	void 더미데이터입력테스트() {
		IntStream.rangeClosed(1, 10).forEach(i->{
			MemberEntity memberEntity=MemberEntity.builder()
					.email("test"+i+"@test.com")
					.password(passwordEncoder.encode("1111"))
					.name("test"+i)
					.build();
			memberEntity.addRole(MemberRole.USER);
			memberEntityRepository.save(memberEntity);
			
			BoardEntity entity=BoardEntity.builder()
					.subject("제목 테스트 "+i)
					.content("내용 테스트 "+i)
					.writer(memberEntity.getName())
					.build();
			boardEntityRepository.save(entity);
		});
		
	}
	
	//@Test
	void board입력테스트() {
		
		BoardEntity entity=BoardEntity.builder()
				.subject("제목 테스트 ")
				.content("내용 테스트 ")
				.writer("작성자")
				.build();
		BoardEntity result=boardEntityRepository.save(entity);
		if(result!=null) {
			log.info("게시글 입력성공! : "+ result);
		}
		
	}
	
	//@Test
	void board모두읽어오기테스트() {
		boardEntityRepository.findAll().forEach(entity->{
			log.info("baord의 데이터 : "+ entity);
		});
	}
	
	
	
	@Test
	void board삭제() {
		//11번삭제
		long bno=11;
		boardEntityRepository.deleteById(bno);
		log.info(bno +"번 데이터 삭제완료!");
	}
	

}
