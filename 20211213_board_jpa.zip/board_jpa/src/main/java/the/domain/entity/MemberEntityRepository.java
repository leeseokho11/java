package the.domain.entity;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository													//t=MemberEntity class, id=pk값의 데이터타입
public interface MemberEntityRepository extends JpaRepository<MemberEntity, Long>{

	Optional<MemberEntity> findByEmail(String string);

	//void deleteByNo(long l);
	
	//쿼리 메서드 만들어서 사용합니다. 
	//find.by, read.. by, count...by, get...by 로 시작해야한다.
	// 쿼리가 복잡한 경우  @Query 이노테이션 사용가능
	
	
}
