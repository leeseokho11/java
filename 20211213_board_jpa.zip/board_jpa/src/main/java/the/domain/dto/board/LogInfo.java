package the.domain.dto.board;

import lombok.Data;
import lombok.NoArgsConstructor;
import the.domain.entity.MemberEntity;

@NoArgsConstructor 
@Data
public class LogInfo { // entity의 내용 일부분만 셋팅(매핑)
	private String email;
	private String name;
	
	
	//생성자에 entity가 파라미터로 제공되고 필드값제공
	public LogInfo(MemberEntity entity) {
		super();
		this.email = entity.getEmail();
		this.name = entity.getName();
	}
	
	
}
