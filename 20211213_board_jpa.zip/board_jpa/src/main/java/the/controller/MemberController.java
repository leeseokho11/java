package the.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import lombok.RequiredArgsConstructor;
import the.domain.dto.member.MemberLoginDto;
import the.domain.dto.member.MemberSaveDto;
import the.service.MemberService;
import the.service.impl.MemberServiceImpl;

@RequiredArgsConstructor
@Controller
public class MemberController {
	
	//@Autowired // : 멤버필드 인젝션방법
	final MemberService service; 
	// 생성자 인젝션방법 : final 필드+@RequiredArgsConstructor
	
	@GetMapping("/mem/reg")
	public String regPage() {
		return "member/registration";
	}
	
	@PostMapping("/mem/reg")
	public String memberReg(MemberSaveDto saveDto, Model model) {
		return service.save(saveDto , model);
	}
	
	
	@GetMapping("/mem/login") //로그인페이지이동
	public String loginPage() {
		return "member/login";
	}
	
	@PostMapping("/mem/login") //로그인 기능을 처리
	public String login(MemberLoginDto loginDto, Model model) {
		return service.login(loginDto, model);
	}
	
	@GetMapping("/mem/logout") //로그아웃 처리
	public String logout() {
		return service.logout();
	}
	
	
}
