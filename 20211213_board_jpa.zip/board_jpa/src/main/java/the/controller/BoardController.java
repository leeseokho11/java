package the.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import the.domain.dto.board.BoardUpdateDto;
import the.service.BoardService;

@Controller
public class BoardController {
	
	@Autowired
	private BoardService service;
	
	@GetMapping("/board") 
	//만약에 page파라미터가 존재하지않으면 null값이고
	//null int page 파싱시 오류가 발생합니다.
	public String list(@RequestParam(defaultValue = "1") int page,Model model) {
		//return service.list(model);// 리턴정보 : 주소
		//return service.listAll(model);// 리턴정보 : 주소
		System.out.println("pageNO : "+ page);
		
		
		return service.listPage(page, model);
	}
	
	@GetMapping("/board/{no}") //@PathVariable uri의 변수를 파라미터 변수에 매핑
	public String detail(@PathVariable long no, Model model) {
		
		//return service.detail(no, model);
		return service.detailAndReadCount(no, model);
	}
	
	//@PatchMapping : 수정처리시 변경된사항만 수정
	//@PutMapping : 수정처리시
	//@DeleteMapping : 삭제
	//HiddenHttpMethodFilter 객체가 bean으로 등록되어야한다.delete
	//@PostMapping("/board/{no}") //@PathVariable uri의 변수를 파라미터 변수에 매핑
	@DeleteMapping("/board/{no}") //@PathVariable uri의 변수를 파라미터 변수에 매핑
	public String delete(@PathVariable long no) {
		System.out.println("삭제할 번호 : "+no);
		return service.delete(no);
	}
	
	@PutMapping("/board/{no}")                //mapping을 위한 setter 메서드 있어야합니다. 
	public String update(@PathVariable long no, BoardUpdateDto dto) {
		System.out.println("update data : "+ dto);
		return service.update(no, dto);
	}
	
}
