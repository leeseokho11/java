package the.service.impl;

import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import lombok.RequiredArgsConstructor;
import the.domain.dto.board.LogInfo;
import the.domain.dto.member.MemberLoginDto;
import the.domain.dto.member.MemberSaveDto;
import the.domain.entity.MemberEntity;
import the.domain.entity.MemberEntityRepository;
import the.service.MemberService;

@RequiredArgsConstructor
@Service
public class MemberServiceImpl implements MemberService {
	
	final MemberEntityRepository repository;
	final HttpSession session;
	
	
	@Override
	public String save(MemberSaveDto saveDto, Model model) {
		
		/*
		  MemberEntity entity=MemberEntity.builder() 
		  .email(saveDto.getEmail())
		  .password(saveDto.getPassword()) 
		  .name(saveDto.getName()) 
		  .build();
		  
		  repository.save(entity);
		 */
		
		repository.save(saveDto.toEntity());
		
		model.addAttribute("success", saveDto.getName()+"님 <br>회원가입을 축하합니다.");
		
		return "member/login";
	}

	//로그인 처리 
	@Override
	public String login(MemberLoginDto loginDto, Model model) {
		//로그인 성공시 , 로그인실패시 2가지로 표현
		//로그인 성공시와 실패를 판단하려면 email과 password 일치 여부에 따라 판단
		Optional<MemberEntity> result= repository.findByEmail(loginDto.getEmail());
		if(result.isPresent()) {
			//email이 존재하는경우 비밀번호 비교
			MemberEntity entity= result.get();
			if(entity.getPassword().equals(loginDto.getPassword())) {
				//로그인 성공시 -> session에 로그인정보 저장
				session.setAttribute("logInfo", new LogInfo(entity) );
				return "redirect:/"; //
			}
		}
		
		//로그인 실패시
		model.addAttribute("error","이메일이나 비밀번호가 존재하지 않거나 다릅니다.");
		return "/member/login"; //로그인실패하면 login.html 페이지로 이동
	}
	//로그아웃 처리
	@Override 
	public String logout() { 
		session.removeAttribute("logInfo");
		return "redirect:/mem/login";
	}
	
}
