package the.service;

import org.springframework.ui.Model;

import the.domain.dto.member.MemberLoginDto;
import the.domain.dto.member.MemberSaveDto;

public interface MemberService {

	String save(MemberSaveDto saveDto, Model model);

	String login(MemberLoginDto loginDto, Model model);

	String logout();

}
