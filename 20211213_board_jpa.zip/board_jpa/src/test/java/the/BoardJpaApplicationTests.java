package the;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import the.domain.entity.BoardEntity;
import the.domain.entity.BoardEntityRepository;
import the.domain.entity.MemberEntity;
import the.domain.entity.MemberEntityRepository;

@SpringBootTest
class BoardJpaApplicationTests {
	
	@Autowired
	BoardEntityRepository  repository;
	
	@Autowired
	MemberEntityRepository memRepository;
	
	//@Transactional
	//@Test
	void 멤버수정() {
		String newPassword="1111";
		MemberEntity result= memRepository.findByEmail("test02@test.com")
		//.map((e)->{return e.updatePassword("1111");})
		//.map(e->e.updatePassword(newPassword))
		.get();
		
		result.updatePassword(newPassword);
		System.out.println("수정후 멤버정보 : " +result);
		memRepository.save(result);
	}
	
	//@Test
	void 멤버읽어오기() {
		MemberEntity result= memRepository.findByEmail("test01@test.com").get();
		System.out.println("읽어온 결과 : "+ result);
	}
	
	//@Test
	void 멤버삭제테스트() {
		memRepository.deleteById(2L);
		//memRepository.deleteByNo(1L);
	}
	
	//@Test
	void 멤버삽입테스트() {
		MemberEntity entity=MemberEntity.builder()
							.email("test02@test.com")
							.password("1234")
							.name("test02")
							.build();
			
			memRepository.save(entity);
	}
	
	
	
	//@Test
	void 데이터일괄저장테스트() {
		IntStream.rangeClosed(101, 300).forEach((i)->{
			repository.save(BoardEntity.builder()
					.subject("제목테스트"+i)
					.content("내용테스트"+i)
					.writer("작성자"+i)
					.createdDate(LocalDateTime.now())
					.build());
		});
	}
	//@Test
	void 더미데이터저장() {
		for(int i=1; i<=10; i++) {
			BoardEntity entity=BoardEntity.builder()
					.subject("제목테스트"+i)
					.content("내용테스트"+i)
					.writer("작성자"+i)
					.createdDate(LocalDateTime.now())
					.build();
			repository.save(entity);
		}
		
	}
	
	//@Test
	void 데이터읽기ID이용테스트() {
		//Optional<BoardEntity> result=repository.findById(1L);
		BoardEntity result=repository.findById(1L).get();
		System.out.println(result);
	}
	
	//@Test
	void 데이터읽기() {
		List<BoardEntity> result=repository.findAll();
		for(BoardEntity entity : result) {
			System.out.println(entity);
		}
	}
	
	

}
