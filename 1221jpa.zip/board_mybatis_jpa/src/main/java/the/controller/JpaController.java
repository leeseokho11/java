package the.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class JpaController {
	
	@GetMapping("/jpaboards") // -> templates/ common에서 처음 설정한 href="/jpaboards"
	public String listPage() {
		return "jpaboard/list"; //-> jpaboard/list.html
	}
}
