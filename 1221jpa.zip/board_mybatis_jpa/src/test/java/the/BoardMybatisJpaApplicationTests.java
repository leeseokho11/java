package the;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import the.domain.dto.myBoard.MyBoardDto;
import the.mapper.MyBoardMapper;

@SpringBootTest
class BoardMybatisJpaApplicationTests {
	
	
	@Autowired
	MyBoardMapper boardMapper;
	
	//@Test
	void 데이터읽어오기(){
		MyBoardDto myboardDto=boardMapper.find(1L);
	}
	
	//@Test
	void 데이터입력() {
		IntStream.rangeClosed(21, 100000).forEach(i->{
			MyBoardDto myBoardDto=MyBoardDto.builder()
					.subject("제목테스트"+i)
					.content("내용테스트"+i)
					.writer("노원그린"+i)
					.build();
			boardMapper.save(myBoardDto);
			
		});
		
	}

}
