package the.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import the.domain.dto.goods.Goods;

@Mapper
public interface GoodsMapper {

	void save(Goods dto);

	List<Goods> findAll();

}
