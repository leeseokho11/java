package the.domain.dto.visual;

import lombok.Data;
import the.domain.entity.Visual;

@Data
public class VisualSaveDto {
	private String title;
	private String sub;
	
	public Visual toEntity() {
		return Visual.builder()
				.title(title).sub(sub)				
				.build();
	}
}
