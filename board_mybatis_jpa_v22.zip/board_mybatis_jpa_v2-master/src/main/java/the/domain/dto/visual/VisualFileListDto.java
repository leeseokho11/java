package the.domain.dto.visual;

import lombok.Data;
import the.domain.entity.Visual;
import the.domain.entity.VisualFile;

@Data
public class VisualFileListDto {
	private long fno;
	private String filePath;
	private String fileName;
	private long fileSize;
	
	private VisualListDto visual;

	public VisualFileListDto(VisualFile entity) {
		this.fno = entity.getFno();
		this.filePath = entity.getFilePath();
		this.fileName = entity.getFileName();
		this.fileSize = entity.getFileSize();
		this.visual=new VisualListDto(entity.getVisual());
	}
	
	
}
