package the.domain.dto.file;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class FileDto {
	private long fno;
	private String fileName;
	private String fileURI;
	private long fileSize;
	private long bno;
}
