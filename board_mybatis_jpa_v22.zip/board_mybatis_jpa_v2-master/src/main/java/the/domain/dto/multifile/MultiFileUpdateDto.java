package the.domain.dto.multifile;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class MultiFileUpdateDto {
	private String subject;
	private String content;
	
	MultipartFile addFile;
	
}
