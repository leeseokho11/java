package the.domain.entity.mutifile;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface MultiFileBoardEntityRepository extends JpaRepository<MultiFileBoardEntity, Long>{

	
	//사용자가 만들 쿼리메서드영역
	//multiFileEntityRepository 사용하지않고 
	//MultiFileBoardEntityRepository 사용할때 MultiFileEntity 로 접근하기 위해서@Query 사용
	@Modifying//DML(insert,update,delete)
	@Query("delete from MultiFileEntity f where f.fno=?1")
	int deleteFile(long fno);
}
