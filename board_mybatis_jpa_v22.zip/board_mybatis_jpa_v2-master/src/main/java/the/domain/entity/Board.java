package the.domain.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;


@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@EntityListeners(AuditingEntityListener.class)
@SequenceGenerator(name = "gen_seq_jpab",
				sequenceName = "seq_jpab", initialValue = 1, allocationSize = 1)
@Table(name = "jpa_board")
@Entity//DB 와 매핑되는 클래스
public class Board {// Repository 접근가능

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "gen_seq_jpab")
	private long no;
	@Column(nullable = false)
	private String subject;
	@Column(nullable = false)
	private String content;
	@Column(nullable = false)
	private String writer;
	private int readCount;
	@CreatedDate
	private LocalDateTime createdDate;
	@LastModifiedDate
	private LocalDateTime updatedDate;
	
}
