package the.domain.entity.mutifile;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Vector;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.core.io.ClassPathResource;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import the.domain.dto.multifile.MultiFileUpdateDto;

@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@EntityListeners(AuditingEntityListener.class)
@SequenceGenerator(name = "gen_seq_mbo",
		sequenceName = "seq_mbo", initialValue = 1, allocationSize = 1)
@Table(name = "multi_board")
@Entity
public class MultiFileBoardEntity {
	
	@Id
	@GeneratedValue(generator = "gen_seq_mbo", strategy = GenerationType.SEQUENCE)
	private long bno;
	
	@Column(nullable = false)
	private String subject;
	@Column(nullable = false)
	private String content;
	@Column(nullable = false)
	private String writer;
	private int readCount;
	@CreatedDate
	private LocalDateTime createdDate;
	@LastModifiedDate
	private LocalDateTime updatedDate;
	
	//Cascading처리: 종속객체 의 영속성 전이
	//ALL : 모든변경사항에대해 전이
	//PERSIT : 저장시에만 전이
	//MERGE : 병합시에만 전이
	//REMOVE : 삭제시
	//REFRESH : 엔티티 매니저의 refresh()호출시
	//DETACH : 부모 엔티티가 detach되면 자식 엔티티역시 detach
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)//default :LAZY  //종속객체 로딩옵션 LAZY :지연로딩  EAGER:즉시로딩
	@JoinColumn(name = "bno")//기존테이블을 이용해서 조인 : fk many 쪽 테이블에 생성
	private List<MultiFileEntity> files;
	
	
	public MultiFileBoardEntity update(MultiFileUpdateDto dto) {
		subject=dto.getSubject();
		content=dto.getContent();
		//파일업로드
		MultipartFile mf=dto.getAddFile();
		long fileSize=mf.getSize();
		//추가할 파일이 존재할떄 처리
		if(fileSize>0) {
			//파일정보
			String fileOrgName=mf.getOriginalFilename();
			String[] strs=fileOrgName.split("[.]");
			String fileNewName=strs[0]+"_"+(System.nanoTime()/100000)+"."+strs[1];
			String filePath="/upload/";
			ClassPathResource cpr=new ClassPathResource("static"+filePath);
			try {
				mf.transferTo(new File(cpr.getFile(), fileNewName));
			} catch (IllegalStateException | IOException e) {e.printStackTrace();}
			//첨부파일 추가
			if(files==null) {files=new Vector<>();}
			MultiFileEntity fent=MultiFileEntity.builder().fileSize(fileSize).fileOrgName(fileOrgName).fileNewName(fileNewName).filePath(filePath).build();
			files.add(fent);
		}//if(fileSeize)
		return this;
	}//update()
	
}










