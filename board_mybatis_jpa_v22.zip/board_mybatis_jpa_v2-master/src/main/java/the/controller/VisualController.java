package the.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import lombok.RequiredArgsConstructor;
import the.domain.dto.visual.VisualSaveDto;
import the.service.VisualService;
import the.service.impl.VisualServiceImpl;

@RequiredArgsConstructor
@Controller
public class VisualController {
	
	private final VisualService service;
	
	@GetMapping("/visuals/write")
	public String writePage() {
		return "visual/write";
	}
	
	@ResponseBody
	@PostMapping("/visuals/temp")
	public String temp(MultipartFile file) {
		return service.tempFileUpload(file);
	}
	
	@PostMapping("/visuals/write")
	public String write(MultipartFile file, VisualSaveDto dto) {
		//이미 이미지는  temp폴더에 업로든된상황
		return service.moveAndSave(file, dto);
	}
	
	//실제 페이지이동만..
	@GetMapping("/visuals")
	public String list() {
		return "visual/list";
	}
	
	//데이터를 갖고오기위한 요청
	//@ResponseBody
	@GetMapping("/visuals/list")
	public String getlist(Model model) {
		return service.getList(model);
	}
	
	@GetMapping("/visuals/index-list")
	public String getVisualList(Model model) {
		return service.getVisualList(model);
	}
}
