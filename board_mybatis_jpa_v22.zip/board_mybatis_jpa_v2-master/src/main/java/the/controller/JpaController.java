package the.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import lombok.RequiredArgsConstructor;
import the.service.JpaService;


@RequiredArgsConstructor
@Controller
public class JpaController {
	
	final JpaService service;
	
	@GetMapping("/jpaboards")//?page=1
	public String listPage(Model model,@RequestParam(defaultValue = "1") int page) {
		return service.getList(model , page);
	}
}
