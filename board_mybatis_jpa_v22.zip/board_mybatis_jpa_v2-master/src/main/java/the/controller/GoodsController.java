package the.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import the.domain.dto.goods.Goods;
import the.service.GoodsService;
import the.service.impl.GoodsServiceImpl;

@Controller
public class GoodsController {
	
	@Autowired
	private GoodsService service;
	
	@ResponseBody
	@PostMapping("/goods/temp")
	public String tempImgUpload(MultipartFile fileImg) {
		
		return service.tempImgUpload(fileImg);
		
	}
	
	@GetMapping("/goods")
	public String list(Model model) {
		return service.getList(model);
	}
	

	@GetMapping("/goods/write")
	public String write() {
		return "goods/write";
	}
	
	@PostMapping("/goods")
	public String write(Goods dto, MultipartFile file) {
		return service.saveAndImgUpload(dto, file);
	}
	
	@PostMapping("/goods/write")
	public String writePreUpload(Goods dto, MultipartFile file) {
		return service.saveAndImgTempToLoc(dto, file);
	}
}
