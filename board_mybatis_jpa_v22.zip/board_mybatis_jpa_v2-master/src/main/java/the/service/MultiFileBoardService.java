package the.service;

import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import the.domain.dto.multifile.MultiFileBoardDto;
import the.domain.dto.multifile.MultiFileUpdateDto;

public interface MultiFileBoardService {

	String fileUploadAndSave(MultiFileBoardDto dto);

	String fileUploadAndSave(MultiFileBoardDto dto, MultipartHttpServletRequest req);

	String getList(Model model, int page);

	String getDeateil(long bno, Model model);

	void fileDownload(long fno, long bno,  HttpServletResponse response);

	String fileDelete(long fno, long bno);

	String update(long bno, MultiFileUpdateDto dto);

	

}
