package the.service.impl;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.io.FileUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import lombok.RequiredArgsConstructor;
import the.domain.dto.PageInfo;
import the.domain.dto.multifile.MultiFileBoardDto;
import the.domain.dto.multifile.MultiFileUpdateDto;
import the.domain.entity.mutifile.MultiFileBoardEntity;
import the.domain.entity.mutifile.MultiFileBoardEntityRepository;
import the.domain.entity.mutifile.MultiFileEntity;
import the.domain.entity.mutifile.MultiFileEntityRepository;
import the.service.MultiFileBoardService;

@RequiredArgsConstructor
@Service
public class MultiFileBoardServiceImpl implements MultiFileBoardService {
	
	private final MultiFileBoardEntityRepository repository;
	
	@Override
	public String fileUploadAndSave(MultiFileBoardDto dto, MultipartHttpServletRequest req) {
		
		Iterator<String> it=req.getFileNames();
		while(it.hasNext()) {
			List<MultipartFile> list=req.getFiles(it.next());
			System.out.println("사이즈 : "+list.size());
		}
		//System.out.println(it.hasNext());
		/*
		List<MultiFileEntity> files=fileUpload(dto.getFiles());
		MultiFileBoardEntity entity=MultiFileBoardEntity.builder()
				.subject(dto.getSubject()).content(dto.getContent()).writer(dto.getWriter())
				.files(files)
				.build();
		repository.save(entity);
		*/
		return "multifile/list";
	}
	
	@Override
	public String fileUploadAndSave(MultiFileBoardDto dto) {
		
		List<MultiFileEntity> files=fileUpload(dto.getFiles());
		
		MultiFileBoardEntity entity=MultiFileBoardEntity.builder()
				.subject(dto.getSubject()).content(dto.getContent()).writer(dto.getWriter())
				.files(files)
				.build();
		repository.save(entity);
		return "redirect:/multifiles";
	}

	private List<MultiFileEntity> fileUpload(List<MultipartFile> files) {
		List<MultiFileEntity> result=new Vector<>(); 
		
		for(MultipartFile mf : files) { //MultipartFile 무조건1가 존재합니다.
			long fileSize=mf.getSize();
			System.out.println("파일사이즈 : " + fileSize);
			if(fileSize==0) return null; //파일이 존재하지 않은경우
			
			String fileOrgName= mf.getOriginalFilename();//원본파일이름
			//String fileNewName=fileOrgName+
			// img_1.jpg ---> 
			String[] strs=fileOrgName.split("[.]");
			System.out.println(strs.length);
			System.out.println("파일이름 : "+ strs[0]);
			System.out.println("확장자 : "+ strs[1]);
			String fileNewName=strs[0]+"_"+(System.nanoTime()/100000)+"."+strs[1];
			System.out.println("fileNewName: "+fileNewName);
			String filePath="/upload/";//+current.format(formatter)+"/";
			//entity 정보 저장
			MultiFileEntity entity=MultiFileEntity.builder()
					.fileSize(fileSize).fileOrgName(fileOrgName).fileNewName(fileNewName).filePath(filePath)
					.build();
			result.add(entity);
			
			ClassPathResource cpr=new ClassPathResource("static"+filePath);
			try {
				File location=cpr.getFile();
				mf.transferTo(new File(location, fileNewName));
				System.out.println("파일업로드완료");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}//for End
		
		return result;
	}

	@Override
	public String getList(Model model, int page) {
		
		int size=10;
		Pageable pageable=PageRequest.of(page-1, size, Direction.DESC, "bno");
		Page<MultiFileBoardEntity>  result=repository.findAll(pageable);
		List<MultiFileBoardEntity> list= result.getContent();
		model.addAttribute("list", list);
		if(!list.isEmpty()) // 리스트가 존재하지 않으면 page정보가 무의미
			model.addAttribute("pd", new PageInfo(result.getTotalPages(), page, 5));
		return "multifile/list";
	}

	@Override
	public String getDeateil(long bno, Model model) {
		
		MultiFileBoardEntity ent=repository.findById(bno).get();
		model.addAttribute("detail", ent);
		
		return "multifile/detail";
	}

	
	final MultiFileEntityRepository multiFileEntityRepository;
	
	@Override
	public void fileDownload(long fno, long bno, HttpServletResponse response ) {
		// 파일 다운로드 구현
		MultiFileEntity result=multiFileEntityRepository.findById(fno).orElseThrow();
		System.out.println(result);
		//다운로드 대상...newName으로 되어있는 파일
		ClassPathResource cpr=new ClassPathResource("static"+result.getFilePath());
		try {
			//File locatin=cpr.getFile();//파일위치
			File downloadFile=new File(cpr.getFile(), result.getFileNewName());
			//1.파일을 byte[]로 읽어들인다.
			//org.apache.commons.io.FileUtils; 가 필요합니다.
			byte[] downfile=FileUtils.readFileToByteArray(downloadFile);
			//배열정보를 다운로드 할예정
			////////////////////////////////////////////////
			//Header에 설정이 없는 경우 다운로드가 아닌 브라우저에서 파일이 열리므로 설정이 필요
			//ContentType 데이터를 어떻게 분석,파싱할건지에대한 결정
			response.setContentType("aplication/octet-stream");
			response.setContentLengthLong(result.getFileSize());
			//"Content-Disposition", "attachment; 브라우저가 파일을 다운받게하는 설정
			//fileName= 다운로드 될 파일의 이름을 지정, 파일이름은 인코딩
			response.setHeader("Content-Disposition", "attachment; fileName=\""+
					URLEncoder.encode(result.getFileOrgName(),"UTF-8")+"\";");
			
			response.setHeader("Content-Transfer-Encoding","binary");
			/////////////////////////////////////////////////
			response.getOutputStream().write(downfile);
			response.getOutputStream().flush();//출력스트림 버퍼비우기
			response.getOutputStream().close();//닫기
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
	
	//@Transactional
	@Override
	public String fileDelete(long fno, long bno) {
		MultiFileEntity result=multiFileEntityRepository.findById(fno).orElseThrow();
		//서버의 파일삭제..
		ClassPathResource cpr=new ClassPathResource("static"+result.getFilePath());
		try {
			//업로드된 파일삭제
			FileUtils.delete(new File(cpr.getFile(), result.getFileNewName()));
			//DB정보삭제
			multiFileEntityRepository.deleteById(fno);
			//repository.deleteFile(fno);//board -> 파일접근
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "redirect:/multifiles/"+bno;
	}

	@Transactional
	@Override
	public String update(long bno, MultiFileUpdateDto dto) {
		repository.findById(bno).map(e->e.update(dto)).orElseThrow(); //update할 대상 객체
		return "redirect:/multifiles/"+bno;
	}
	
	
	

}













