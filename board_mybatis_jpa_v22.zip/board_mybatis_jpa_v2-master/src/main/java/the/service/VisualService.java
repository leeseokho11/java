package the.service;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import the.domain.dto.visual.VisualSaveDto;

public interface VisualService {

	String tempFileUpload(MultipartFile file);

	String moveAndSave(MultipartFile file, VisualSaveDto dto);

	String getList(Model model);

	String getVisualList(Model model);


}
